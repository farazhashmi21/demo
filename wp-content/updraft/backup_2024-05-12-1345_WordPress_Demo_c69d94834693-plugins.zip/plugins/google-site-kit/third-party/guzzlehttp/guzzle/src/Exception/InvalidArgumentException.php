<?php

namespace Google\Site_Kit_Dependencies\GuzzleHttp\Exception;

final class InvalidArgumentException extends \InvalidArgumentException implements \Google\Site_Kit_Dependencies\GuzzleHttp\Exception\GuzzleException
{
}
